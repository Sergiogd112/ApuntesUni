﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlightLib;

namespace SimulatorConsole
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Escribe el numero de aviones");
            int naviones;
            try
            {
                naviones = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Error de formato");

                naviones = Convert.ToInt32(Console.ReadLine());
            }
            int i = 0;
            FlightPlan[] planes = new FlightPlan[naviones];
            string identificador;
            string linea;
            string[] trozos;
            double velocidad;
            double ix, iy;
            double fx, fy;
            while (i < naviones)
            {
                Console.WriteLine("Escribe el identificador");
                //   string nombre = Console.ReadLine();
                identificador = Console.ReadLine();

                Console.WriteLine("Escribe la velocidad");
                try
                {
                    velocidad = Convert.ToDouble(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Error de formato");

                    velocidad = Convert.ToDouble(Console.ReadLine());
                }

                Console.WriteLine("Escribe las coordenadas de la posición inicial, separadas por un blanco");
                linea = Console.ReadLine();
                trozos = linea.Split(' ');
                try
                {
                    ix = Convert.ToDouble(trozos[0]);
                    iy = Convert.ToDouble(trozos[1]);
                }
                catch (FormatException)
                {
                    Console.WriteLine("Error de formato");

                    linea = Console.ReadLine();
                    trozos = linea.Split(' ');
                    ix = Convert.ToDouble(trozos[0]);
                    iy = Convert.ToDouble(trozos[1]);
                }

                Console.WriteLine("Escribe las coordenadas de la posición final, separadas por un blanco");
                try
                {
                    linea = Console.ReadLine();
                    trozos = linea.Split(' ');
                    fx = Convert.ToDouble(trozos[0]);
                    fy = Convert.ToDouble(trozos[1]);
                }
                catch (FormatException)
                {
                    Console.WriteLine("Error de formato");

                    linea = Console.ReadLine();
                    trozos = linea.Split(' ');
                    fx = Convert.ToDouble(trozos[0]);
                    fy = Convert.ToDouble(trozos[1]);
                }

                planes[i] = new FlightPlan(identificador, ix, iy, fx, fy, velocidad);
                i++;
            }
            Console.WriteLine("Escribe el numero de ciclos");
            int ciclos;
            try
            {
                ciclos = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Error de formato");

                ciclos = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("Escribe la distancia de seguridad");
            double distanciaSeguridad;
            try
            {
                distanciaSeguridad = Convert.ToDouble(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Error de formato");

                distanciaSeguridad = Convert.ToDouble(Console.ReadLine());
            }

            int ciclo = 0;
            int j = 0;
            while (ciclo < ciclos)
            {
                i = 0;
                while (i < naviones)
                {
                    planes[i].EscribeConsola();
                    planes[i].Mover(10);
                    i++;
                }
                i = 0;
                while (i < naviones)
                {
                    j = i;
                    while (j < naviones)
                    {
                        if (planes[i].Conflicto(planes[j], distanciaSeguridad))
                        {
                            Console.WriteLine("El avion {0} y {1} estan en conflicto", planes[i].GetId(), planes[j].GetId());
                        }
                        j++;
                    }
                    i++;
                }
                ciclo++;
            }


            Console.ReadLine();


        }
    }
}
