﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FlightLib;

namespace SimulatorConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escribe el identificador");
            //   string nombre = Console.ReadLine();
            string identificador = Console.ReadLine(); ;

            Console.WriteLine("Escribe la velocidad");
            double velocidad = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Escribe las coordenadas de la posición inicial, separadas por un blanco");
            string linea = Console.ReadLine();
            string[] trozos = linea.Split(' ');
            double ix = Convert.ToDouble(trozos[0]);
            double iy = Convert.ToDouble(trozos[1]);

            Console.WriteLine("Escribe las coordenadas de la posición final, separadas por un blanco");
            linea = Console.ReadLine();
            trozos = linea.Split(' ');
            double fx = Convert.ToDouble(trozos[0]);
            double fy = Convert.ToDouble(trozos[1]);

            FlightPlan plan_a = new FlightPlan(identificador, ix, iy, fx, fy, velocidad);


            plan_a.EscribeConsola();
            plan_a.Mover(10);
            plan_a.EscribeConsola();

            Console.ReadLine();


        }
    }
}
